import RadarVisualizer from './components/RadarVisualizer.tsx';
import TerminalLogs from './components/TerminalLogs.tsx';
import { useState } from 'react';

const apps=[
 {id:'tracker', name:'Z-Ghost Tracker IA', date:'8 juin 2026', desc:'Z-Ghost Tracker powered by Gemini Core V7 Pro Final.', icon:'✦', color:'bg-blue-500'},
 {id:'lte', name:'Z-GHOST LTE', date:'21 juil. 2026', desc:'Secure AI Logic Dashboard featuring NETSECUREPRO', icon:'📶', color:'bg-yellow-500'},
 {id:'trafker', name:'z-ghosttrafker-z', date:'il y a 11 jours', desc:'Analyseur et traceur de préfixes réseau cellulaire', icon:'Z', color:'bg-purple-500'},
 {id:'netsecure', name:'NetSecurePro IA', date:'il y a 10 jours', desc:'Zero-Trust AI Security Gateway (Z-CORE & Z-PUCE)', icon:'🛡️', color:'bg-sky-500'},
 {id:'zcore', name:'Z-CORE Terminal Display', date:'11 sept. 2026', desc:'Professional telemetry dashboard, POSIX sandbox', icon:'📊', color:'bg-blue-400'},
 {id:'claude', name:'Module Z-CORE AiCLAUDE', date:'8 sept. 2026', desc:'Banc intégration et simulateur délégation AI', icon:'M', color:'bg-purple-400'},
 {id:'milyes', name:'MILYES-IA CORE v4.0.9', date:'30 août 2026', desc:'Terminal souverain et console multi-agents IA', icon:'🤖', color:'bg-orange-500'},
];

export default function App(){
 const [selected,setSelected]=useState(apps[0]);
 const [launched,setLaunched]=useState(false);
 return (
  <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col">
    <header className="border-b border-zinc-800 p-3 flex justify-between items-center">
      <div className="flex gap-3 items-center">
        <div className="w-8 h-8 bg-emerald-500/20 border border-emerald-500/50 rounded-lg flex items-center justify-center">⚡</div>
        <div><div className="font-black tracking-widest text-sm">Z-GHOST-TRACKER <span className="bg-zinc-800 px-2 py-0.5 rounded text-xs ml-2">IA</span></div>
        <div className="text-[10px] text-zinc-500">IA_LOGIC_SIGNATURE:ZOUBIROU-IA-2025 | GEMINI CORE V7 PRO FINAL → V9 NANS CORE</div></div>
      </div>
      <div className="flex items-center gap-2 text-xs border border-emerald-500/30 bg-emerald-500/10 px-3 py-1 rounded-full text-emerald-400">● SYSTEM ONLINE</div>
    </header>
    <div className="flex-1 grid grid-cols-12 gap-4 p-4">
      <div className="col-span-3 space-y-3">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <div className="text-xs tracking-widest text-zinc-400 mb-3">CORE ENGINE</div>
          <div className="text-[11px] text-zinc-500">FIRMWARE</div>
          <div className="text-emerald-400 font-mono text-sm border-l-2 border-emerald-400 pl-2 mb-3">GEMINI CORE V7 PRO FINAL</div>
          <div className="text-[11px] text-zinc-500">LOGIC SIGNATURE</div>
          <div className="text-cyan-400 font-mono text-xs border-l-2 border-cyan-400 pl-2">IA_LOGIC_SIGNATURE:ZOUBIROU-IA-2025</div>
        </div>
        <div className="space-y-2">
          {apps.map(a=>(
            <button key={a.id} onClick={()=>setSelected(a)} className={`w-full text-left p-3 rounded-xl border ${selected.id===a.id?'border-emerald-500/50 bg-zinc-900':'border-zinc-800 bg-zinc-900/50 hover:border-zinc-700'} transition`}>
              <div className="flex gap-2"><div className={`w-8 h-8 rounded-lg ${a.color} flex items-center justify-center text-white font-bold text-xs`}>{a.icon}</div>
              <div className="flex-1"><div className="text-xs font-semibold">{a.name}</div><div className="text-[10px] text-zinc-500 truncate">{a.desc}</div><div className="text-[10px] text-zinc-600 mt-1">{a.date}</div></div></div>
            </button>
          ))}
        </div>
      </div>
      <div className="col-span-6 space-y-4">
        <TerminalLogs/>
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-6"><RadarVisualizer/></div>
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4">
          <div className="flex justify-between items-center"><span className="text-xs">Selected: {selected.name}</span><button onClick={()=>setLaunched(true)} className="bg-gradient-to-r from-orange-500 to-amber-500 text-black font-black px-6 py-2 rounded-lg text-xs tracking-widest">▶ LANCER {launched?'✓':''}</button></div>
          {launched && <div className="mt-3 text-emerald-400 font-mono text-xs">MERGING 7 MODULES INTO MILYES-IA V9 NANS CORE ... [OK] - LICENSE NETSECUREPRO.CA VALIDATED - Z-PUCE API READY - GHOST PROTOCOL ACTIVE</div>}
        </div>
      </div>
      <div className="col-span-3 space-y-3">
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4"><div className="text-xs tracking-widest text-zinc-400 mb-2">ACTIVE ENTITIES</div><div className="text-xs font-mono space-y-1"><div className="flex justify-between"><span>Z-GHOST Nodes</span><span className="text-emerald-400">7 ONLINE</span></div><div className="flex justify-between"><span>Flux Rating</span><span>0.08</span></div><div className="flex justify-between"><span>Sector</span><span>7G</span></div><div className="flex justify-between"><span>License</span><span className="text-yellow-400">NETSECUREPRO.CA</span></div></div></div>
        <div className="bg-zinc-900 border border-orange-500/30 rounded-xl p-4"><div className="text-xs font-bold">LANCER_BIN.HTML5 UNIFIED</div><div className="text-[10px] text-zinc-500 mt-2">All modules merged. Ready to deploy to AI Studio, Netlify, or milyes-ia.api</div><div className="mt-3 text-[10px]">Contact: milyes@netsecurepro.ca</div></div>
      </div>
    </div>
  </div>
 )
}
