import { useEffect, useState } from 'react';
const logs=[
"[SYS] Powering on core systems...",
"[CORE] Initializing GEMINI CORE V7 PRO FINAL...",
"[CORE] Upgrade path: V7 PRO FINAL -> V9 NANS CORE ... [OK]",
"[NET] License NETSECUREPRO.CA validated securely.",
"[NET] IA_LOGIC_SIGNATURE:ZOUBIROU-IA-2025 verified.",
"[TRACKER] Scanning perimeter sector 7G...",
"[TRACKER] Ethereal frequencies calibrating...",
"[TRACKER] Anomaly detected: Flux rating 0.08...",
"[TRACKER] Triangulating non-corporeal signatures...",
"[Z-GHOST] Ghost Protocol ACTIVE - 72h battery",
"[Z-PUCE] Z-Puce API Ready - milyes-ia.api/v9/puce/infer",
"[SSRF] SSRF GUARD Active - protection enabled",
"[SYS] Secure terminal connection active.",
"[SYS] All 7 modules merged into UNIFIED V9."
];
export default function TerminalLogs(){
  const [visible,setVisible]=useState<string[]>([]);
  useEffect(()=>{ let i=0; const iv=setInterval(()=>{ if(i<logs.length){ setVisible(v=>[...v,logs[i]]); i++; } else clearInterval(iv); },300); return ()=>clearInterval(iv);},[]);
  return (
    <div className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-4 font-mono text-xs">
      <div className="text-zinc-400 mb-3 tracking-widest">CONSOLE OUTPUT</div>
      <div className="space-y-1 text-emerald-400">{visible.map((l,k)=><div key={k}>{l}</div>)}<span className="inline-block w-2 h-4 bg-emerald-400 animate-pulse ml-1"/></div>
    </div>
  )
}
