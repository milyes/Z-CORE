import { motion } from 'framer-motion'; import { useEffect, useState } from 'react';
export default function RadarVisualizer(){
  const [angle,setAngle]=useState(0);
  useEffect(()=>{ const i=setInterval(()=>setAngle(a=>(a+2)%360),30); return ()=>clearInterval(i);},[]);
  return (
    <div className="relative w-full aspect-square max-w-[420px] mx-auto bg-zinc-900 rounded-full border border-emerald-500/20 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.15),transparent_70%)]"/>
      {[1,2,3].map(r=><div key={r} className="absolute rounded-full border border-emerald-500/10" style={{inset:`${r*15}%`}}/>)}
      <motion.div className="absolute w-[50%] h-[2px] bg-gradient-to-r from-transparent to-emerald-400 origin-left top-1/2 left-1/2"
        style={{rotate:`${angle}deg`}}/>
      <div className="absolute w-3 h-3 bg-emerald-400 rounded-full shadow-[0_0_12px_#10b981] left-[38%] top-[62%] animate-pulse"/>
      <div className="absolute bottom-3 w-full text-center text-[10px] tracking-[0.3em] text-emerald-400/60">SPATIAL ANOMALY RADAR</div>
    </div>
  )
}
