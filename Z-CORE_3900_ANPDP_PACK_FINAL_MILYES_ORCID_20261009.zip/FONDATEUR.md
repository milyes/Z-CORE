# Fondateur
MOHAMMED ILYES ZOUBIROU
- ORCID: 0009-0007-7571-3178
- Github: MILYES - https://github.com/MILYES
- Email: milyes@netsecurepro.ca
- Instagram: @ilyyesl / @Mzoubirou
- Projet: IA22, LOGICVMQEM, AIMEDIXAL, Z-CORE BENCH 3900
